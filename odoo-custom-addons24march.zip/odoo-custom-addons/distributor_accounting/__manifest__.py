# -*- coding: utf-8 -*-

{
    'name': 'Distributor Accounting',
    'version': '13.0',
    'category': 'Accounting',
    'summary': 'Accounting Reports, Asset Management and Account Budget For Odoo13 Community Edition Distributor accounting',
    'sequence': '8',
    'website': 'http://www.ideenkreisetech.com',
    'author': 'Ideenkreise Tech Pvt Ltd',
    'maintainer': 'Ideenkreise Tech Pvt Ltd',
    'license': 'LGPL-3',
    'support': 'ideenkreise@gmail.com',
    'website': '',
    #'depends': ['accounting_pdf_reports', 'om_account_asset', 'om_account_budget','om_account_accountant'],
    'depends': ['om_account_accountant'],
    'demo': [],
    'data': [
        # 'wizard/change_lock_date.xml',
        'data/vendor_data.xml',
        'data/cron_sync_data.xml',
        'security/ir.model.access.csv',
        'views/distributor_acc_view.xml',
        # 'data/general_report.xml'
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'qweb': [],
}
