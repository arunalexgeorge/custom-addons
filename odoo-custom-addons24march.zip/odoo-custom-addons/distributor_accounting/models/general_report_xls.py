from odoo.tools.misc import xlsxwriter
from odoo import api, fields, models, _
from odoo.exceptions import UserError
import io
import base64

class AccountReportGeneralLedger(models.TransientModel):
    _inherit = "account.common.account.report"
    _name = "account.report.general.ledger"
    _description = "General Ledger Report"

    initial_balance = fields.Boolean(string='Include Initial Balances',
                                     help='If you selected date, this field '
                                          'allow you to add a row to display '
                                          'the amount of debit/credit/balance '
                                          'that precedes the filter you\'ve '
                                          'set.')
    sortby = fields.Selection(
        [('sort_date', 'Date'), ('sort_journal_partner', 'Journal & Partner')],
        string='Sort by', required=True, default='sort_date')
    journal_ids = fields.Many2many('account.journal',
                                   'account_report_general_ledger_journal_rel',
                                   'account_id', 'journal_id',
                                   string='Journals', required=True)

    report_type = fields.Selection([('purchase', 'Purchase'), ('sale', 'Sale')], string='Report Type')

    def _print_report(self, data):
        data = self.pre_print_report(data)
        data['form'].update(self.read(['initial_balance', 'sortby'])[0])
        if data['form'].get('initial_balance') and not data['form'].get(
                'date_from'):
            raise UserError(_("You must define a Start Date"))
        records = self.env[data['model']].browse(data.get('ids', []))
        return self.env.ref(
            'base_accounting_kit.action_report_general_ledger').with_context(
            landscape=True).report_action(records, data=data)


    def generate_xlsx_report(self):
        file_data = io.BytesIO()
        workbook = xlsxwriter.Workbook(file_data)
        worksheet = workbook.add_worksheet("PO Comparison Sheet")
        date_format = '%Y-%m-%d'
        number_of_vendor = 0
        vendor_ids = []
        if self._context.get('lang'):
            lang_id = self.env['res.lang']._search([('code', '=', self._context['lang'])])
        if lang_id:
            date_format = self.env['res.lang'].browse(lang_id).date_format

        for record in self:
            order_id = record.mapped('line_ids.purchase_lines.order_id')
            for order in order_id:
                if order.state != 'cancel':
                    number_of_vendor = number_of_vendor + 1
                    vendor_ids.append(order.partner_id)
        for record in self:
            # if vender is not count less than or equal to 1 then cant create po_comapre
            if number_of_vendor < 1:
                raise UserError(_('No RFQ available for the Purchase agreement. Please add some RFQ to compare'))
            else:
                style0 = workbook.add_format(
                    {'bold': True, 'border': True, 'font_size': 11, 'align': 'center', 'bg_color': 'orange', })
                style1 = workbook.add_format(
                    {'bold': True, 'border': True, 'font_size': 12, 'align': 'center', 'bg_color': 'yellow', })
                style2 = workbook.add_format(
                    {'bold': True, 'border': True, 'font_size': 19, 'align': 'center', 'bg_color': '#f9a5de', })
                style4 = workbook.add_format({'bold': True, 'border': True, 'align': 'center'})
                style6 = workbook.add_format({'border': True, 'align': 'left'})
                style7 = workbook.add_format({'border': True, 'align': 'center'})
                style8 = workbook.add_format({'border': True, 'align': 'right'})
                center = (3 + number_of_vendor * 2)
                worksheet.merge_range(1, 0, 0, center, 'RFQ Price Comparison Sheet', style2)
                worksheet.merge_range(3, 0, 3, 1, 'Request Req Number', style4)
                worksheet.write(3, 2, self.name, style7)
                worksheet.merge_range(4, 0, 4, 1, 'Department Name', style4)
                worksheet.write(4, 2, record.department_id.name, style7)
                worksheet.write(3, 4, 'Date', style4)
                worksheet.write(3, 5, record.date_start.strftime(date_format), style7)
                worksheet.write(4, 4, 'Req. User', style4)
                worksheet.write(4, 5, record.requested_by.name, style7)
                worksheet.merge_range(6, 0, 6, 3, 'SUPPLIER', style1)
                col = 4

                # vendors details are write to sheet here
                for vendor in vendor_ids:
                    worksheet.merge_range(6, col, 6, col + 1, vendor.name, style1)
                    worksheet.write(7, col, 'Rate', style0)
                    worksheet.write(7, col + 1, 'Amount', style0)
                    col += 2
                worksheet.write(7, 0, 'Sl No.', style0)
                worksheet.write(7, 1, 'Materials', style0)
                worksheet.write(7, 2, 'Quantity', style0)
                worksheet.write(7, 3, 'UoM', style0)
                sl_no = 1
                row = 8
                col = 0

                # all the values are write to sheet
                count = 0
                for line in record.line_ids:
                    worksheet.write(row, col, sl_no, style8)
                    col += 1
                    worksheet.write(row, col, line.name, style6)
                    col = col + 1
                    worksheet.write(row, col, line.product_qty, style8)
                    col += 1
                    worksheet.write(row, col, line.product_uom_id.name, style6)
                    col += 1

                    for vendor in vendor_ids:

                        po_lines = line.purchase_lines.filtered(lambda x: x.partner_id == vendor)
                        qty = 0
                        amount = 0
                        for po_line in po_lines:
                            qty += po_line.product_uom_qty
                            amount += po_line.price_total

                        worksheet.write(row, col, po_line.price_total, style8)
                        # worksheet.write(row, col, qty, style8)
                        col += 1

                        worksheet.write(row, col, amount, style8)

                        col += 1
                    row += 1
                    col = 0
                    sl_no += 1
                # purchase request name to be added with name of the xls file
                filename = (self.name + '-Sheet-' + '.xlsx')
                workbook.close()
                file_data.seek(0)
                data = file_data.read()
                file_data.close()
                attach_id = self.env['report.wizard'].create({'attachment': base64.encodestring(data),
                                                              'attach_name': filename})

                return {
                    'type': 'ir.actions.act_window',
                    'name': ('Download Purchase Order Comparison Sheet'),
                    'res_model': 'report.wizard',
                    'res_id': attach_id.id,
                    'view_type': 'form',
                    'view_mode': 'form',
                    'target': 'new',
                }