# # -*- coding: utf-8 -*-
#
# from odoo import models, fields, api ,_
# from odoo.exceptions import UserError,ValidationError
# import cx_Oracle
# import mysql.connector
# import collections
# import requests
# import json
# import qrcode
# from odoo import tools
# import base64
# from io import BytesIO
# from datetime import datetime
#
# class AccountMoveLine(models.Model):
#     _inherit = 'account.move'
#     distributor_id = fields.Many2one('res.partner', string='Distributor')
#     customer_id = fields.Many2one('res.partner', string='Customer')
#
# # class AccountMoveLine(models.Model):
# #     _inherit = "account.move"
# #     delivery_date = fields.Date(string="Delivery Date")
#
# # class SaleOrder(models.Model):
# #     _inherit = 'sale.order'
# #     @api.depends('sale_order')
# #     def action_confirm(self):
# #         res = super(SaleOrder, self).action_confirm()
# #         for do_pick in self.picking_ids:
# #             do_pick.write({'notes': self.note})
# #         return res
# #
# #
# #
# # class SaleOrder(models.Model):
# #     _inherit = 'purchase.order'
# #     @api.onchange('analytic_account_id')
# #     def _onchange_analytic_account_id(self):
# #         for order in self:
# #             analytic_id = order.analytic_account_id
# #             for line in order.order_line:
# #                 line.account_analytic_id = analytic_id
#
#
# class DistributorAccounting(models.Model):
#     _name = 'distributor.acc'
#
#     # distributor_id = fields.Many2one('res.partner', string='Distributor')
#
#     def sync_database0(self):
#         print("Entered Distributor Data Sync")
#         # establishing the connection
#         conn = mysql.connector.connect(user='eastern_user', password='Eastern*123##', host='172.30.1.242',
#                                        database='KL_SCA_AGENCYDB')
#         # Creating a cursor object using the cursor() method
#         cursor = conn.cursor()
#         # Retrieving single row
#         sql_distributerDetails = '''SELECT * from tbl_kl_agency_details'''
#         # Executing the query
#         cursor.execute(sql_distributerDetails)
#         row_distributerDetails = cursor.fetchall()
#         print('Total Row(s):', cursor.rowcount)
#         for row in row_distributerDetails:
#             distributerDetails_dict = {
#                 'name': row[1],
#                 'currency_id': 20,
#                 'street': row[3],
#                 'street2': " ",
#                 'city': " ",
#                 'zip': " ",
#                 'phone': " ",
#                 'email': " ",
#                 'vat': row[4],
#                 # 'company_type': 'company',
#             }
#             duplicate_distributerDetails = self.env['res.e'].search([('name', '=', row[1])])
#             if not duplicate_distributerDetails:
#                 distributerDetails_obj = self.env['res.company'].create(distributerDetails_dict)
#                 print("Distributor Data Added")
#             else:
#                 print("Distributor Data Already Exist")
#             #Adding Distributor Details to Database
#             distributerDetails = self.env['res.company'].search([('name', '=', row[1])], limit=1)
#             UserDetails = self.env['res.users'].search([('company_id', '=', row[1])])
#             PartnerDetails = self.env['res.partner'].search([('company_id', '=', row[1])])
#             if not UserDetails:
#                 for row in row_distributerDetails:
#                     # Getting Distributor ID
#                     # distributerDetails = self.env['res.users'].search([('name', '=', row[1])])
#                     print(distributerDetails)
#                     distributerUserDetails_dict = {
#                         'name': row[1],
#                         # 'company_id': distributerDetails.id,
#                         # 'company_ids': PartnerDetails.id,
#                         'login': row[1]
#
#                     }
#                     print(distributerUserDetails_dict)
#                     duplicate_distributerUserDetails = self.env['res.users'].search([('name', '=', row[1])])
#                     if not duplicate_distributerUserDetails:
#                         distributerUserDetails_obj = self.env['res.users'].create(distributerUserDetails_dict)
#                         print("Distributor User Data Added")
#                     else:
#                         print("Distributor User Data Already Exist")
#         #     distributerDetails = self.env['res.company'].search([('name', '=', row[1])])
#         #     if distributerDetails:
#         #         creditAccountsData = {
#         #             'name': row[1] + 'creditAccount',
#         #             'internal_group': 'income',
#         #             'company_id': distributerDetails.id,
#         #             'code': 'INV',
#         #             'type': 'sale',
#         #             'invoice_reference_type': 'invoice',
#         #             'invoice_reference_model': 'odoo',
#         #         }
#         #         debitAccountsData = {
#         #             'name': row[1] + 'debitAccount',
#         #             'internal_group': 'expense',
#         #             'company_id': distributerDetails.id,
#         #             'code': 'INV',
#         #             'type': 'sale',
#         #             'invoice_reference_type': 'invoice',
#         #             'invoice_reference_model': 'odoo',
#         #         }
#         #         journalData = {
#         #             'name': row[1] + 'TaxINV',
#         #             'company_id': distributerJournalDetails.id,
#         #             'code': 'INV',
#         #             'type': 'sale',
#         #             'invoice_reference_type': 'invoice',
#         #             'invoice_reference_model': 'odoo',
#         #         }
#         #         journalDetails_obj = self.env['account.journal'].create(journalData)
#         # Closing the connection
#         conn.close()
#         print("DistributorUserDataCompleted")
#
#
#
#     def sync_database(self):
#         print("Entered Distributor Sales Data Sync")
#         # # Distributor Sales Data Sync
#         print("Entered Distributor Sales Data Sync")
#         # establishing the connection
#         conn = mysql.connector.connect(user='eastern_user', password='Eastern*123##', host='172.30.1.242', database='KL_SCA_AGENCYDB')
#         # Creating a cursor object using the cursor() method
#         cursor = conn.cursor()
#         # Retrieving single row
#         sql_salesData = '''SELECT * from tbl_kl_agency_sales_normal'''
#         # Executing the query
#         cursor.execute(sql_salesData)
#         # row_salesData = cursor.fetchall()
#         row_salesData = cursor.fetchmany(size=100)
#         print('Total Row(s):', cursor.rowcount)
#         for row in row_salesData:
#             #Getting Distributor ID
#             distributerDetail = self.env['res.company'].search([('name', '=', row[1])])
#
#             #Getting Customer ID
#             customerDetail = self.env['res.partner'].search([('name', '=', row[9])])
#             # print(customerDetail, "Duplicate customerDetail")
#             if not customerDetail:
#                 customerDetail_dict = {
#                     'name': row[9],
#                     'currency_id': 20,
#                     'street': row[10],
#                     'street2': " ",
#                     'city': " ",
#                     'zip': " ",
#                     'phone': " ",
#                     'email': " ",
#                     'vat': row[11]
#                 }
#
#                 customerDetail_created = self.env['res.partner'].create(customerDetail_dict)
#
#             salesData_dict = {}
#             customerDetail = self.env['res.partner'].search([('name', '=', row[9])])
#             salesData_obj = self.env['sale.order'].search([('name', '=', row[8])])
#             if not salesData_obj:
#                 salesData_dict = {
#                     # 'invoice_sequence_number_next': row[1],
#                     'name': row[8],
#                     'date_order': row[6],
#                     # 'invoice_date': row[6],
#                     # 'state': "draft",
#                     # 'type': "out_invoice",
#                     # 'journal_id': 1,
#                     'company_id': distributerDetail.id,
#                     # 'distributor_id': distributerDetail.id,
#                     # 'customer_id': customerDetail.id,
#                     # 'invoice_user_id': 1,
#                     'currency_id': 20,
#                     'partner_id': customerDetail.id,
#                 }
#                 salesData_obj = self.env['sale.order'].create(salesData_dict)
#             #     print("Distributor Data Added")
#             prod_obj = self.env['product.product'].search([('name', '=', row[16])], limit=1)
#             # duplicate_product = self.env['account.move.line'].search([('product_id', '=', prod_obj.id), ('move_id', '=', salesData_obj.id)], limit=1)
#             # print(duplicate_product, "duplicate product")
#             # if not prod_obj:
#             #     product_line_dict = {
#             #         'name': row[16],
#             #         'list_price': row[19],
#             #     }
#             #     product_created = self.env['product.template'].create(product_line_dict)
#             #     product_variant = self.env['product.product'].search([('product_tmpl_id', '=', product_created.id)])
#             tax_variant = self.env['account.tax'].search([('amount', '=', row[14]), ('type_tax_use', '=', "sale"), ('name', '=', "GST%")])
#             # print(product_variant, "product tmpl")
#             invoice_move_line_dict = {
#                 'order_id': salesData_obj.id,
#                 # 'date': row[6],
#                 'product_id': prod_obj.id,
#                 'product_qty': float(row[20]),
#                 'price_unit': float(row[19]),
#                 # 'tax_ids': tax_variant.id,
#                 # 'tax_base_amount': row[24],
#             }
#             # salesData_dict.update({'invoice_line_ids': invoice_move_line_dict})
#             # salesData_obj = self.env['account.move'].create(salesData_dict)
#             invoice_line_created = self.env['sale.order.line'].create(invoice_move_line_dict)
#         # Closing the connection
#         conn.close()
#         print("saledatacompleted")
#
#     def sync_database2(self):
#         print("Entered Purchase Sync")
#         connection = cx_Oracle.connect("APPSRO", "APPSRO", "172.30.1.110:1525/DEV")
#         print(connection, "connection successful")
#         cursor = connection.cursor()
#         # cursor.execute("SELECT * FROM XXESTREZI.XXEST_ITEM_TRANS_FRWD_STG WHERE TRANSFER_TYPE LIKE '%DISTRV' FETCH NEXT 500 ROWS ONLY")  # use triple quotes if you want to spread your query across multiple lines
#         cursor.execute("select * from XXESTREZI.XXEST_ITEM_TRANS_FRWD_STG WHERE TRANSFER_TYPE LIKE '%DISTRV%' AND XXEST_ITEM_TRANS_FRWD_STG.TRANSACTION_DATE >= to_date('1.2.' || 2021, 'DD.MM.YYYY') AND CUSTOMER_NAME = 'FAAZ AGENCIES' FETCH NEXT 500 ROWS ONLY")
#         names = [c[0] for c in cursor.description]
#         cursor.rowfactory = collections.namedtuple("XXEST_ITEM_TRANS_FRWD_STG", names)
#
#
#         for row in cursor:
#             print(row)
#             purchase_obj = self.env['purchase.order'].search([('name', '=', row.INVOICE_NUMBER)], limit=1)
#             company_obj = self.env['res.company'].search([('name', '=', row.CUSTOMER_NAME)], limit=1)
#             # purchase_dict = {}
#             if not purchase_obj:
#                 purchase_dict = {
#                     'date_order': row.TRANSACTION_DATE,
#                     # 'company_id': company_obj.id,
#                     'company_id': 1,
#                     'partner_id': 1,
#                     'name': row.INVOICE_NUMBER or False,
#                     'picking_type_id': 1,
#                     'currency_id': 20,
#                 }
#                 cursor.execute("select * from XXESTREZI.XXEST_ITEM_TRANS_FRWD_STG WHERE TRANSFER_TYPE LIKE '%DISTRV%' AND XXEST_ITEM_TRANS_FRWD_STG.TRANSACTION_DATE >= to_date('1.2.' || 2021, 'DD.MM.YYYY') AND CUSTOMER_NAME = 'FAAZ AGENCIES' AND INVOICE_NUMBER = "+row.INVOICE_NUMBER+" FETCH NEXT 500 ROWS ONLY")
#                 names = [c[0] for c in cursor.description]
#                 cursor.rowfactory = collections.namedtuple("XXEST_ITEM_TRANS_FRWD_STG", names)
#                 # purchase_obj = self.env['purchase.order'].create(purchase_dict)
#                 purchase_line_dict = {}
#                 for row in cursor:
#                     prod_obj = self.env['product.product'].search([('name', '=', row.ITEM_DESC)], limit=1)
#                     # tax_variant = self.env['account.tax'].search([('amount', '=', row.CGST + row.IGST), ('type_tax_use', '=', "purchase"), ('name', '=', "GST%")], limit=1)
#                     purchase_line_dict = (0, 0, {
#                         'order_id': purchase_obj.id,
#                         'date_planned': row.TRANSACTION_DATE,
#                         'name': row.INVOICE_NUMBER or False,
#                         # 'company_id': company_obj.id,
#                         'company_id': 1,
#                         'partner_id': 1,
#                         'product_id': 1,
#                         'product_qty': row.PRIMARY_QUANTITY or False,
#                         'price_unit': row.UNIT_PRICE or False,
#                         # 'price_subtotal': row.UNIT_PRICE * row.PRIMARY_QUANTITY,
#                     })
#                     purchase_dict.update({'order_line': purchase_line_dict})
#                     invoice_dict_obj = self.env['purchase.order'].create(purchase_dict)
#         # connection.commit()
#         print("updatedsplit")
#
#
#
#     # def sync_database2(self):
#     #     print("enterd oracle sync")
#     #     pulled_data = []
#     #     connection = cx_Oracle.connect("APPSRO", "APPSRO", "172.30.1.110:1525/DEV")
#     #     print(connection, "connection successful")
#     #     cursor = connection.cursor()
#     #     cursor.execute("SELECT * FROM XXESTREZI.XXEST_ITEM_TRANS_FRWD_STG WHERE TRANSFER_TYPE LIKE '%DISTRV' FETCH NEXT 500 ROWS ONLY")  # use triple quotes if you want to spread your query across multiple lines
#     #     names = [c[0] for c in cursor.description]
#     #     cursor.rowfactory = collections.namedtuple("XXEST_ITEM_TRANS_FRWD_STG", names)
#     #
#     #     # print(cursor)
#     #
#     #     for row in cursor:
#     #         # print(row)
#     #         invoice_dict = {}
#     #         invoice_obj = self.env['account.move'].search([('name', '=', row.INVOICE_NUMBER)], limit=1)
#     #         company_obj = self.env['res.partner'].search([('name', '=', row.CUSTOMER_NAME)], limit=1)
#     #         if not invoice_obj:
#     #             invoice_dict = {
#     #                 'state': "draft",
#     #                 'journal_id': 2,
#     #                 'date': row.TRANSACTION_DATE,
#     #                 'company_id': self.env.company.id,
#     #                 'distributor_id': company_obj.id,
#     #                 'partner_id': company_obj.id,
#     #                 'name': row.INVOICE_NUMBER or False,
#     #                 'currency_id': 20,
#     #                 'type': 'in_invoice',
#     #                 'to_check': False,
#     #             }
#     #             # invoice_obj = self.env['account.move'].create(invoice_dict)
#     #             prod_obj = self.env['product.product'].search([('name', '=', row.ITEM_DESC)], limit=1)
#     #             duplicate_product = self.env['account.move.line'].search([('product_id', '=', prod_obj.id), ('move_id', '=', invoice_obj.id)], limit=1)
#     #             print(duplicate_product, "duplicate product")
#     #             if not duplicate_product:
#     #                 product_line_dict = {
#     #                     'name': row.ITEM_DESC,
#     #                     'list_price': row.UNIT_PRICE,
#     #                 }
#     #                 product_created = self.env['product.template'].create(product_line_dict)
#     #                 product_variant = self.env['product.product'].search([('product_tmpl_id', '=', product_created.id)], limit=1)
#     #                 tax_variant = self.env['account.tax'].search([('amount', '=', row.CGST + row.IGST), ('type_tax_use', '=', "purchase"), ('name', '=', "GST%")], limit=1)
#     #                 print(product_variant, "product tmpl")
#     #                 invoice_move_line_dict = (0, 0, {
#     #                     'move_id': invoice_obj.id,
#     #                     'journal_id': 2,
#     #                     'quantity': row.PRIMARY_QUANTITY or False,
#     #                     'price_unit': row.UNIT_PRICE or False,
#     #                     'price_subtotal': row.UNIT_PRICE * row.PRIMARY_QUANTITY,
#     #                     'tax_ids': tax_variant,
#     #                     "recompute_tax_line": True,
#     #                 })
#     #                 invoice_dict.update({'invoice_line_ids': invoice_move_line_dict})
#     #                 invoice_dict_obj = self.env['account.move'].create(invoice_dict)
#     #     # connection.commit()
#     #     print("updatedsplit")

# -*- coding: utf-8 -*-

from odoo import models, fields, api ,_
from odoo.exceptions import UserError,ValidationError
import cx_Oracle
import mysql.connector
import collections
import requests
import json
import qrcode
from odoo import tools
import base64
from io import BytesIO
from datetime import datetime

# class AccountMoveLine(models.Model):
#     _inherit = 'account.move'
#     distributor_id = fields.Many2one('res.partner', string='Distributor')
#     customer_id = fields.Many2one('res.partner', string='Customer')

# class AccountMoveLine(models.Model):
#     _inherit = "account.move"
#     delivery_date = fields.Date(string="Delivery Date")


class ResCompany(models.Model):
    _inherit = 'res.company'

    def write(self, values):
        if values.get('name'):
            raise UserError(_('You cannot edit company name'))
        return super(ResCompany, self).write(values)

# class ResPartner(models.Model):
#     _inherit = 'res.partner'

    # def write(self, values):
    #     if values.get('name'):
    #         raise UserError(_('You cannot edit user name'))
    #     return super(ResPartner, self).write(values)

class DistributorAccounting(models.Model):
    _name = 'distributor.acc'

    def productSync(self):
        print("enterd oracle product sync")
        connection = cx_Oracle.connect("APPSRO", "APPSRO", "172.30.1.110:1525/DEV")
        productCursor = connection.cursor()
        productCursor.execute("SELECT * FROM XXESTREZI.XXEST_ITEM_TRANS_FRWD_STG WHERE TRANSFER_TYPE LIKE '%DISTRV' AND XXEST_ITEM_TRANS_FRWD_STG.TRANSACTION_DATE >= to_date('1.2.' || 2021, 'DD.MM.YYYY') FETCH NEXT 15000 ROWS ONLY")  # use triple quotes if you want to spread your query across multiple lines
        names = [c[0] for c in productCursor.description]
        productCursor.rowfactory = collections.namedtuple("XXEST_ITEM_TRANS_FRWD_STG", names)
        for productRow in productCursor:
            product_id = self.env['product.product'].sudo().search([('name', '=', productRow.ITEM_DESC)], limit=1) or False
            if not product_id:
                uom_ids=self.env['uom.uom'].sudo().search([])
                unit_id=self.env.ref('uom.product_uom_unit') and self.env.ref('uom.product_uom_unit').id or False
                for record in uom_ids:
                    if record.name.upper() ==productRow.TRANSACTION_UOM.upper():
                        unit_id=record.id
                        break
                product_line_dict = {
                                'name': productRow.ITEM_DESC,
                                'list_price': productRow.UNIT_PRICE,
                                'l10n_in_hsn_code': productRow.HSN_CODE,
                                # 'uom_id': unit_id,
                                # 'uom_po_id': unit_id,
                                'type':'product',

                            }
                product_id = self.env['product.template'].sudo().create(product_line_dict)
                print(product_id.name)

    def distributorSync(self):
        print("Entered Distributor Data Sync")
        # establishing the connection
        conn = mysql.connector.connect(user='eastern_user', password='Eastern*123##', host='172.30.1.242', database='KL_SCA_AGENCYDB')
        # Creating a cursor object using the cursor() method
        cursor = conn.cursor()
        # Retrieving single row
        sql_distributerDetails = '''SELECT * from tbl_kl_agency_details'''
        # Executing the query
        cursor.execute(sql_distributerDetails)
        row_distributerDetails = cursor.fetchall()
        print('Total Row(s):', cursor.rowcount)
        for row in row_distributerDetails:
            distributerDetails_dict = {
                'name': row[1],
                'currency_id': 20,
                'street': row[3],
                'street2': " ",
                'city': " ",
                'zip': " ",
                'phone': " ",
                'email': " ",
                'vat': row[4],
            }
            duplicate_distributerDetails = self.env['res.company'].search([('name', '=', row[1])])
            if not duplicate_distributerDetails:
                distributerDetails_obj = self.env['res.company'].sudo().create(distributerDetails_dict)
                print("Distributor Data Added")
            else:
                print("Distributor Data Already Exist")
            #Adding Distributor Details to Database
            distributerDetails = self.env['res.company'].search([('name', '=', row[1])], limit=1)
            UserDetails = self.env['res.users'].search([('company_id', '=', row[1])])
            PartnerDetails = self.env['res.partner'].search([('company_id', '=', row[1])])
            if not UserDetails:
                for row in row_distributerDetails:
                    # Getting Distributor ID
                    # distributerDetails = self.env['res.users'].search([('name', '=', row[1])])
                    print(distributerDetails)
                    distributerUserDetails_dict = {
                        'name': row[1],
                        'company_id': distributerDetails.id,
                        'company_ids': [(6,0,[distributerDetails.id])],
                        'login': row[1]

                    }
                    print(distributerUserDetails_dict)
                    duplicate_distributerUserDetails = self.env['res.users'].search([('name', '=', row[1])])
                    if not duplicate_distributerUserDetails:
                        distributerUserDetails_obj = self.env['res.users'].sudo().create(distributerUserDetails_dict)
                        print("Distributor User Data Added")
                    else:
                        print("Distributor User Data Already Exist")
        conn.close()
        print("DistributorUserDataCompleted")

    def create_res_users(self,user_name,street=None,vat=None):
        customer = self.env['res.partner'].sudo().create({
            'name': user_name,
            'street': street or '',
            'vat': vat or '',
        })
        self.env.cr.commit()
        return customer.id or False

    def saleSync(self):
        print("Entered Distributor Sales Data Sync")
        # establishing the connection
        conn = mysql.connector.connect(user='eastern_user', password='Eastern*123##', host='172.30.1.242', database='KL_SCA_AGENCYDB')
        new_conn = mysql.connector.connect(user='eastern_user', password='Eastern*123##', host='172.30.1.242', database='KL_SCA_AGENCYDB')
        # Creating a cursor object using the cursor() method
        cursor = conn.cursor()
        new_cursor = new_conn.cursor()
        # Retrieving single row
        sql_salesData = '''SELECT * from tbl_kl_agency_sales_normal'''
        # Executing the query
        cursor.execute(sql_salesData)
        # row_salesData = cursor.fetchall()
        row_salesData = cursor.fetchmany(size=100)
        conn.close()
        print('Total Row(s):', cursor.rowcount)
        for rowInv in row_salesData:
            invoice_dict = {}
            sale_order = self.env['sale.order'].sudo().search([('name', '=', rowInv[8])],limit=1)
            partener_id = rowInv[9] and self.env['res.partner'].sudo().search(
                [('name', '=', rowInv[9])], limit=1).id or False
            invNo = "SELECT * from tbl_kl_agency_sales_normal WHERE bill_no = "+'"{}"'.format(rowInv[8])
            if not partener_id:
                partener_id=self.create_res_users(rowInv[9])
            invoice = new_cursor.execute("SELECT * from tbl_kl_agency_sales_normal WHERE bill_no = "+'"{}"'.format(rowInv[8]))
            new_salesData = new_cursor.fetchall()
            #for record in new_salesData
            sale_ref=self.env['sale.order'].search([('name', '=',rowInv[8])])
            invoice_date=False
            if not sale_ref:
                order_line = []
                for row in new_salesData:
                    product_id = self.env['product.product'].sudo().search([('name', '=', row[16])],limit=1) or False
                    invoice_date=row[6]
                    if not product_id:
                        uom_ids = self.env['uom.uom'].sudo().search([])
                        unit_id = self.env.ref('uom.product_uom_unit') and self.env.ref(
                            'uom.product_uom_unit').id or False
                        for record in uom_ids:
                            if record.name.upper() == row[18].upper():
                                unit_id = record.id
                                break
                        product_line_dict = {
                            'name': row[16],
                            'list_price': row[19],
                            'l10n_in_hsn_code': row[17],
                            # 'uom_id': unit_id,
                            # 'uom_po_id': unit_id
                            'type': 'product',
                        }
                        product_id = self.env['product.template'].sudo().create(product_line_dict)
                        self.env.cr.commit()
                    if product_id:
                        tax_variant = self.env['account.tax'].search(
                            [('amount', '=', row[14]), ('type_tax_use', '=', "sale"),
                             ('name', 'like', "GST%")], limit=1)
                        order_line.append((0, 0, {
                            # 'display_type': False,
                            'sequence': 10,
                            'product_id': product_id.id,
                            'name': product_id.name or '',
                            # 'date_planned': '2021-03-21 05:22:14',
                            # 'account_analytic_id': False,
                            'product_uom_qty': row[20] or 0,
                            # 'qty_received_manual': 0,
                            'product_uom': product_id.uom_id.id or self.env.ref('uom.product_uom_unit') and self.env.ref('uom.product_uom_unit').id or False,
                            'price_unit': row[19] or 0,
                            'tax_id': tax_variant and [(6, 0, [tax_variant.id])] or [] or False,
                            'discount': round((float(row[23]) / float(row[22])) * 100,2)
                        }))
                if partener_id:
                    sale_order_1 = False
                    # try:
                    sale_order_1 = self.env['sale.order'].sudo().create({
                        'partner_id': partener_id,
                        'name': rowInv[8] or '',
                        'order_line': order_line
                    })
                    self.env.cr.commit()
                    if sale_order_1:
                        sale_order_1.action_confirm()
                        invoice=sale_order_1._create_invoices(final=True)
                        invoice.invoice_date=invoice_date
                        invoice.name=rowInv[8]

        self.env.cr.commit()
        # Closing the connection
        conn.close()
        print("saledatacompleted")

    def purchaseSync(self):
        print("enterd oracle sync")
        pulled_data = []
        connection = cx_Oracle.connect("APPSRO", "APPSRO", "172.30.1.110:1525/DEV")
        print(connection, "connection successful")
        cursor = connection.cursor()
        new_cursor = connection.cursor()
        # cursor.execute("SELECT * FROM XXESTREZI.XXEST_ITEM_TRANS_FRWD_STG WHERE TRANSFER_TYPE LIKE '%DISTRV' FETCH NEXT 500 ROWS ONLY")  # use triple quotes if you want to spread your query across multiple lines
        #new_cursor.execute("select distinct INVOICE_NUMBER, CUSTOMER_NAME, TRANSACTION_DATE from XXESTREZI.XXEST_ITEM_TRANS_FRWD_STG WHERE TRANSFER_TYPE LIKE '%DISTRV%' AND XXEST_ITEM_TRANS_FRWD_STG.TRANSACTION_DATE >= to_date('1.2.' || 2021, 'DD.MM.YYYY') FETCH NEXT 15 ROWS ONLY")  # use triple quotes if you want to spread your query across multiple lines
        new_cursor.execute("select distinct INVOICE_NUMBER, CUSTOMER_NAME, TRANSACTION_DATE from XXESTREZI.XXEST_ITEM_TRANS_FRWD_STG WHERE TRANSFER_TYPE LIKE '%DISTRV%' AND XXEST_ITEM_TRANS_FRWD_STG.TRANSACTION_DATE >= to_date('1.2.' || 2021, 'DD.MM.YYYY') AND CUSTOMER_NAME ="+"'{}'".format(self.env.company.name)) # use triple quotes if you want to spread your query across multiple lines

        names = [c[0] for c in new_cursor.description]
        new_cursor.rowfactory = collections.namedtuple("XXEST_ITEM_TRANS_FRWD_STG", names)
        for rowInv in new_cursor:
            invoice_dict = {}
            purchase_order = self.env['purchase.order'].sudo().search([('name', '=', rowInv.INVOICE_NUMBER)], limit=1)
            partener_id = rowInv.CUSTOMER_NAME and self.env['res.partner'].sudo().search([('name', '=', rowInv.CUSTOMER_NAME)], limit=1).id or False
            invoice = cursor.execute("SELECT * FROM XXESTREZI.XXEST_ITEM_TRANS_FRWD_STG WHERE INVOICE_NUMBER = "+rowInv.INVOICE_NUMBER)
            names = [c[0] for c in cursor.description]
            cursor.rowfactory = collections.namedtuple("XXEST_ITEM_TRANS_FRWD_STG", names)
            invoice_date=False
            if not purchase_order:
                order_line=[]
                for row in invoice:
                    invoice_date = row.TRANSACTION_DATE
                    product_id = self.env['product.product'].sudo().search([('name', '=', row.ITEM_DESC)], limit=1) or False
                    if not product_id:
                        uom_ids=self.env['uom.uom'].sudo().search([])
                        unit_id=self.env.ref('uom.product_uom_unit') and self.env.ref('uom.product_uom_unit').id or False
                        for record in uom_ids:
                            if record.name.upper() ==row.TRANSACTION_UOM.upper():
                                unit_id=record.id
                                break
                        product_line_dict = {
                                        'name': row.ITEM_DESC,
                                        'list_price': row.UNIT_PRICE,
                                        'l10n_in_hsn_code': row.HSN_CODE,
                                        # 'uom_id': unit_id,
                                        # 'uom_po_id':unit_id
                                            'type': 'product',
                                    }
                        product_id = self.env['product.template'].sudo().create(product_line_dict)
                        self.env.cr.commit()
                    if product_id:
                        tax_variant = self.env['account.tax'].search(
                            [('amount', '=', row.CGST + row.SGST), ('type_tax_use', '=', "purchase"),
                             ('name', 'like', "GST%")], limit=1)
                        order_line.append((0, 0, {
                            'display_type': False,
                                             'sequence': 10,
                                             'product_id': product_id.id,
                                             'name': product_id.name or '',
                                             'date_planned': row.TRANSACTION_DATE or False,
                                             'account_analytic_id': False,
                                             'product_qty': row.PRIMARY_QUANTITY or 0,
                                             'qty_received_manual': 0,
                                             'product_uom': product_id.uom_id.id or self.env.ref('uom.product_uom_unit') and self.env.ref('uom.product_uom_unit').id or False,
                                             'price_unit': row.UNIT_PRICE or 0,
                                             'taxes_id': tax_variant and [(6, 0, [tax_variant.id])] or [],
                        }))

                # company_id_partner = self.env.ref('base.main_partner').id
                # partener_id = rowInv.CUSTOMER_NAME and self.env['res.company'].sudo().search(
                #      [('name', '=', rowInv.CUSTOMER_NAME)], limit=1).id or False
                #
                # partener_id = rowInv.CUSTOMER_NAME and self.env['res.partner'].sudo().search(
                #      [('name', '=', rowInv.CUSTOMER_NAME)], limit=1).id or False
                partener_id = rowInv.CUSTOMER_NAME and self.env['res.partner'].sudo().search(
                    [('name', '=', 'EASTERN CONDIMENTS PVT LTD')], limit=1).id or False
                #partener_id=self.env.ref("distributor_accounting.res_partner_main_est_ventor").id
                if not partener_id:
                    partener_id=self.env['res.partner'].sudo().create({'name': 'EASTERN CONDIMENTS PVT LTD'})
                    self.env.cr.commit()
                if partener_id:
                        purchase_order_1=False
                        # try:
                        purchase_order_1 = self.env['purchase.order'].create({
                                'partner_id': partener_id,
                                #'partner_id': self.env.ref('base.main_partner').id,
                                'name':rowInv.INVOICE_NUMBER or '',
                                'order_line':order_line,
                            })

                        self.env.cr.commit()
                        # except:
                        #     pass
                        if purchase_order_1:
                            purchase_order_1.button_confirm()
                            purchase_order_1.action_view_picking()
                            if purchase_order_1.picking_ids:
                                for picking in purchase_order_1.picking_ids:
                                    picking.button_validate()
                                    pick_to_backorder = self.env['stock.immediate.transfer']
                                    stock_immediate=pick_to_backorder.create({'pick_ids':[(6,0,purchase_order_1.picking_ids.ids)]})
                                    self.env.cr.commit()
                                    stock_immediate.process()
                                #purchase_order_1.action_view_invoice()
                                company_id=self.env.company.id
                                journal = self.env['account.journal'].search([('company_id', '=', company_id), ('type', '=', 'purchase')], limit=1)

                                invoice_dict_obj = self.env['account.move'].sudo().create(
                                    {
                                        'name':rowInv.INVOICE_NUMBER or '',
                                        'type': 'in_invoice',
                                        'company_id': purchase_order_1.company_id.id,
                                        'purchase_id': purchase_order_1.id,
                                        'partner_id': purchase_order_1.partner_id.id,
                                        'invoice_origin':purchase_order_1.name,
                                        'ref': False,
                                        'currency_id':self.env.company and self.env.company.currency_id and self.env.company.currency_id.id,
                                        'journal_id':journal.id or False
                                    })
                                self.env.cr.commit()
                                if invoice_dict_obj:
                                    journal_domain = [
                                        ('type', '=', 'purchase'),
                                        ('company_id', '=', invoice_dict_obj.company_id.id),
                                        # ('currency_id', '=', invoice_dict_obj.partner_id.property_purchase_currency_id and invoice_dict_obj.partner_id.property_purchase_currency_id.id or invoice_dict_obj.partner_id.currency_id and invoice_dict_obj.partner_id.currency_id.id),
                                    ]
                                    default_journal_id = self.env['account.journal'].search(journal_domain, limit=1)
                                    if not default_journal_id:
                                        break
                                    new_lines = self.env['account.move.line']
                                    new_invoice_lines=[]
                                    for line in purchase_order_1.order_line:
                                        lines_invoice=line._prepare_account_move_line(invoice_dict_obj)
                                        lines_invoice.update({'account_id':default_journal_id.default_debit_account_id.id})
                                        new_invoice_lines.append((0,0,lines_invoice))
                                    invoice_dict_obj.invoice_line_ids=new_invoice_lines
                                    invoice_dict_obj.invoice_date = invoice_date
                                    invoice_dict_obj.date = invoice_date
                                    for record in invoice_dict_obj.invoice_line_ids:
                                        record._get_computed_account()
                                        record._onchange_price_subtotal()
                                        record._onchange_mark_recompute_taxes()
                                        self.env.cr.commit()