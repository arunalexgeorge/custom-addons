# -*- coding: utf-8 -*-
# License: Odoo Proprietary License v1.0

from . import controllers
from . import models
from . import wizards
from . import reports
