========================
Accounting Excel Reports
========================
Excel reports for all the financial reports in Odoo. Export Partner Ledger, General Ledger, Journal Audit, Tax report,
Aged Partner Balance, Balance Sheet and Profit & Loss


Installation
============
- www.odoo.com/documentation/13.0/setup/install.html
- Install our custom addon
- If you have doubt, check this video: https://www.youtube.com/watch?v=S7H72B9aaks

Bug Tracker
===========
If any Bugs found, you can contact us in the email, we will support you: odoomates@gmail.com


Maintainer
----------

Odoo Mates

