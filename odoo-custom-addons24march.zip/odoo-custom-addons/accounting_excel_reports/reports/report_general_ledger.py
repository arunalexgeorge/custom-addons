# -*- coding: utf-8 -*-
# License: Odoo Proprietary License v1.0

import logging
from odoo import models


class ReportGeneralLedgerExcel(models.Model):
    _name = "report.accounting_excel_reports.report_generalledger_excel"
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        report_obj = self.env['report.accounting_pdf_reports.report_general_ledger']
        active_ref=self.env['account.report.general.ledger'].browse(self.env.context.get('active_id')) or False
        results = report_obj._get_report_values(obj, data)
        sheet = workbook.add_worksheet()

        format1 = workbook.add_format({'font_size': 14, 'bottom': True, 'right': True, 'left': True, 'top': True,
                                       'align': 'center', 'bold': True, 'bg_color': '#bfbfbf', 'valign': 'vcenter'})
        format2 = workbook.add_format({'font_size': 12, 'align': 'left', 'right': True, 'left': True,
                                       'bottom': True, 'top': True, 'bold': True, 'bg_color': '#bfbfbf'})
        format3 = workbook.add_format({'font_size': 12, 'align': 'right', 'right': True, 'left': True,
                                       'bottom': True, 'top': True, 'bold': True, 'bg_color': '#bfbfbf'})
        format4 = workbook.add_format({'font_size': 10, 'align': 'left', 'bold': True, 'right': True, 'left': True,
                                       'bottom': True, 'top': True})
        format5 = workbook.add_format({'font_size': 10, 'align': 'right', 'bold': True, 'right': True, 'left': True,
                                       'bottom': True, 'top': True})
        format6 = workbook.add_format({'font_size': 10, 'align': 'left', 'bold': False, 'right': True, 'left': True,
                                       'bottom': True, 'top': True, 'text_wrap':'true'})
        format7 = workbook.add_format({'font_size': 10, 'align': 'right', 'bold': False, 'right': True, 'left': True,
                                       'bottom': True, 'top': True})
        format8 = workbook.add_format({'font_size': 10, 'align': 'left', 'bold': False, 'right': True, 'left': True,
                                       'bottom': True, 'top': True, 'num_format': 'yyyy-mm-dd'})

        sheet.set_row(0, 40)
        sheet.set_row(2, 40)
        sheet.set_column(0, 1, 13)
        sheet.set_column(2, 5, 25)
        sheet.set_column(6, 8, 15)

        sheet.merge_range('A1:I1', "General Ledger Report", format1)

        sheet.merge_range('A3:B3', "Journals", format4)
        sheet.write('C3', ', '.join([lt or '' for lt in results['print_journal']]), format6)
        sheet.write('G3', 'Target Moves', format4)
        if data['form']['target_move'] == 'posted':
            sheet.merge_range('H3:I3', 'All Posted Entries', format6)
        else:
            sheet.write('H3:I3', 'All Entries', format6)

        sheet.merge_range('A4:B4', "Display Account", format4)
        if data['form']['display_account'] == 'all':
            sheet.write('C4', 'All', format6)
        elif data['form']['display_account'] == 'movement':
            sheet.write('C4', 'With Movements', format6)
        else:
            sheet.write('C4', 'With balance is not equal to 0', format6)
        sheet.write('G4', 'Sorted By', format4)
        if data['form']['sortby'] == 'sort_date':
            sheet.merge_range('H4:I4', 'Date', format6)
        else:
            sheet.write('H4:I4', 'Journal & Partner', format6)

        if data['form']['date_from']:
            sheet.merge_range('A5:B5', "Date From", format4)
            sheet.write('C5', data['form']['date_from'], format6)
        if data['form']['date_to']:
            sheet.write('G5', "Date To", format4)
            sheet.merge_range('H5:I5', data['form']['date_to'], format6)

        # if active_ref and active_ref.report_type_new == 'purchase':
        #     sheet.write('A7', "Bill Number ", format2)
        #     sheet.write('B7', "Billing Date ", format2)
        #     sheet.write('C7', "Vendor Name", format2)
        #     sheet.write('D7', "Vendor GST", format2)
        #     # sheet.write('E7', "Entry Label", format2)
        #     # sheet.write('F7', "HSN Code", format2)
        #     # sheet.write('E7', "Qty", format3)
        #     # sheet.write('E7', "Rate Of Tax", format3)
        #     sheet.write('E7', "Taxable Value", format3)
        #     sheet.write('F7', "CGST", format2)
        #     sheet.write('G7', "SGST", format3)
        #     sheet.write('H7', "IGST", format3)
        #     # sheet.write('I7', "CESS", format3)
        #     # sheet.write('N7', "Place of Supply", format3)
        #     sheet.write('I7', "Total", format3)
        #
        #     row = 7
        #     col = 0
        #     domain=[('type','=','in_invoice'),('state','!=','cancel')]
        #     if active_ref.company_id:
        #         domain.append(('company_id', '=', active_ref.company_id.id))
        #     account=self.env['account.move'].search(domain)
        #     for record in account:
        #             # for line in record.invoice_line_ids:
        #                 col = 0
        #                 #row += 1
        #                 sheet.write(row, col,record.name or '', format6)
        #                 sheet.write(row, col+1, record.date, format8)
        #                 sheet.write(row, col + 2, record.partner_id and record.partner_id.name  or '', format6)
        #                 sheet.write(row, col +3 ,record.partner_id and record.partner_id.vat  or '', format6)
        #                 # sheet.write(row, col +4 , line.name or line.product_id and line.product_id.name or '', format6)
        #                 # sheet.write(row, col +5 , line.product_id and line.product_id.l10n_in_hsn_code or '', format6)
        #                 # sheet.write(row, col +6, line.quantity, format6)
        #                 # sheet.write(row, col +7 , line.tax_ids and line.tax_ids[0].name, format6)
        #                 sheet.write(row, col +4, record.amount_untaxed, format6)
        #                 cgst = 0
        #                 sgst=0
        #                 igst=0
        #                 cess=0
        #                 for tax in record.amount_by_group:
        #                     if 'cgst' == tax[0].lower():
        #                         cgst=tax[1]
        #                     if 'sgst' == tax[0].lower():
        #                         sgst=tax[1]
        #                     if 'igst' == tax[0].lower():
        #                         igst=tax[1]
        #                     if 'cess' == tax[0].lower():
        #                         cess=tax[1]
        #                 sheet.write(row, col +5, sgst, format6)
        #                 sheet.write(row, col +6, cgst, format6)
        #                 sheet.write(row, col +7, igst, format6)
        #                 # sheet.write(row, col +8, cess, format6)
        #                 sheet.write(row, col +8, record.amount_total, format6)
        #
        #                 # if line.tax_ids:
        #                 #     for tax in line.tax_ids[0].children_tax_ids:
        #                 #         pass
        #
        #                 # sheet.write(row, col +5, tax, format6)
        #                 # sheet.write(row, col +10, sgst, format6)
        #                 # sheet.write(row, col +11, igst, format6)
        #                 # sheet.write(row, col +12, cess, format6)
        #                 # # sheet.write(row, col +13 , 'place of supply', format6)
        #                 # sheet.write(row, col +13, line.price_subtotal, format6)
        #                 row += 1
        #     # sheet.write('A7', "Bill Number ", format2)
        #     # sheet.write('B7', "Billing Date ", format2)
        #     # sheet.write('C7', "Vendor Name", format2)
        #     # sheet.write('D7', "Vendor GST", format2)
        #     # sheet.write('E7', "Entry Label", format2)
        #     # sheet.write('F7', "HSN Code", format2)
        #     # sheet.write('G7', "Qty", format3)
        #     # sheet.write('H7', "Rate Of Tax", format3)
        #     # sheet.write('I7', "Taxable Value", format3)
        #     # sheet.write('J7', "CGST", format2)
        #     # sheet.write('K7', "SGST", format3)
        #     # sheet.write('L7', "IGST", format3)
        #     # sheet.write('M7', "CESS", format3)
        #     # # sheet.write('N7', "Place of Supply", format3)
        #     # sheet.write('N7', "Total", format3)
        #     #
        #     # row = 7
        #     # col = 0
        #     # domain=[('type','=','in_invoice'),('state','!=','cancel')]
        #     # if active_ref.company_id:
        #     #     domain.append(('company_id', '=', active_ref.company_id.id))
        #     # account=self.env['account.move'].search(domain)
        #     # for record in account:
        #     #         for line in record.invoice_line_ids:
        #     #             col = 0
        #     #             #row += 1
        #     #             sheet.write(row, col,record.name or '', format6)
        #     #             sheet.write(row, col+1, record.date, format8)
        #     #             sheet.write(row, col + 2, record.partner_id and record.partner_id.name  or '', format6)
        #     #             sheet.write(row, col +3 ,record.partner_id and record.partner_id.vat  or '', format6)
        #     #             sheet.write(row, col +4 , line.name or line.product_id and line.product_id.name or '', format6)
        #     #             sheet.write(row, col +5 , line.product_id and line.product_id.l10n_in_hsn_code or '', format6)
        #     #             sheet.write(row, col +6, line.quantity, format6)
        #     #             sheet.write(row, col +7 , line.tax_ids and line.tax_ids[0].name, format6)
        #     #             sheet.write(row, col +8, line.price_subtotal, format6)
        #     #             cgst=0
        #     #             sgst=0
        #     #             igst=0
        #     #             cess=0
        #     #             tax_per=line.tax_ids and line.tax_ids[0].amount or 1
        #     #             tax=(tax_per * line.price_subtotal)/100
        #     #             # if line.tax_ids:
        #     #             #     for tax in line.tax_ids[0].children_tax_ids:
        #     #             #         pass
        #     #
        #     #             sheet.write(row, col +9, tax, format6)
        #     #             sheet.write(row, col +10, sgst, format6)
        #     #             sheet.write(row, col +11, igst, format6)
        #     #             sheet.write(row, col +12, cess, format6)
        #     #             # sheet.write(row, col +13 , 'place of supply', format6)
        #     #             sheet.write(row, col +13, line.price_subtotal, format6)
        #     #             row += 1

        # elif active_ref and active_ref.report_type_new == 'sale':
        #     sheet.write('A7', "Bill Number ", format2)
        #     sheet.write('B7', "Billing Date ", format2)
        #     sheet.write('C7', "Vendor Name", format2)
        #     sheet.write('D7', "Vendor GST", format2)
        #     sheet.write('E7', "Entry Label", format2)
        #     sheet.write('F7', "HSN Code", format2)
        #     sheet.write('G7', "Qty", format3)
        #     sheet.write('H7', "Rate Of Tax", format3)
        #     sheet.write('I7', "Taxable Value", format3)
        #     sheet.write('J7', "CGST", format2)
        #     sheet.write('K7', "SGST", format3)
        #     sheet.write('L7', "IGST", format3)
        #     sheet.write('M7', "CESS", format3)
        #     sheet.write('N7', "Place of Supply", format3)
        #     sheet.write('O7', "Total", format3)
        #
        #     row = 7
        #     col = 0
        #     # total=14
        #     # for account in results['Accounts']:
        #     # sheet.merge_range(row, col, row, col + 5, account['code'] + account['name'], format4)
        #     # sheet.write(row, col + 6, account['debit'], format5)
        #     # sheet.write(row, col + 7, account['credit'], format5)
        #     # sheet.write(row, col + 8, account['balance'], format5)
        #     domain = [('type', '=', 'out_invoice'), ('state', '!=', 'cancel')]
        #     account = self.env['account.move'].search(domain)
        #     for record in account:
        #         for line in record.invoice_line_ids:
        #             col = 0
        #             # row += 1
        #             sheet.write(row, col, record.name or '', format6)
        #             sheet.write(row, col + 1, record.date, format8)
        #             sheet.write(row, col + 2, record.partner_id and record.partner_id.name or '', format6)
        #             sheet.write(row, col + 3, record.partner_id and record.partner_id.vat or '', format6)
        #             sheet.write(row, col + 4, line.name or line.product_id and line.product_id.name or '', format6)
        #             sheet.write(row, col + 5, line.product_id and line.product_id.l10n_in_hsn_code or '', format6)
        #             sheet.write(row, col + 6, line.quantity, format6)
        #             sheet.write(row, col + 7, line.tax_ids[0].name, format6)
        #             sheet.write(row, col + 8, line.price_subtotal, format6)
        #             sheet.write(row, col + 9, 'cgst', format6)
        #             sheet.write(row, col + 10, 'sgst', format6)
        #             sheet.write(row, col + 11, 'igst', format6)
        #             sheet.write(row, col + 12, 'cess', format6)
        #             sheet.write(row, col + 13, 'place of supply', format6)
        #             sheet.write(row, col + 14, line.price_subtotal, format6)
        #             row += 1
        #     sheet.write('A7', "Bill Number ", format2)
        #     sheet.write('B7', "Billing Date ", format2)
        #     sheet.write('C7', "Route", format2)
        #     sheet.write('D7', "Route Code", format2)
        #     sheet.write('E7', "Route Type", format2)
        #     sheet.write('F7', "Customer Name", format2)
        #     sheet.write('G7', "Customer Address", format3)
        #     sheet.write('H7', "Customer GSTIN", format3)
        #     sheet.write('I7', "Bill Type", format3)
        #     sheet.write('J7', "Payment Method", format2)
        #     sheet.write('K7', "Gross Amount", format3)
        #     sheet.write('L7', "Cash Discount", format3)
        #     sheet.write('M7', "Taxable Amount", format3)
        #     sheet.write('N7', "Total SGST Amount", format3)
        #     sheet.write('O7', "Total CGST Amount", format3)
        #     sheet.write('P7', "Total IGST Amount", format2)
        #     sheet.write('Q7', "Total KF CESS Amount", format3)
        #     sheet.write('R7', "Total Tax Amount", format3)
        #     sheet.write('S7', "Total Amount", format3)
        #     sheet.write('T7', "Net Amount", format2)
        #     sheet.write('U7', "Quantity Discount Amount", format3)
        #     sheet.write('V7', "Total TCS Amount", format3)
        #     sheet.write('W7', "Bill Amount", format3)
        if active_ref and active_ref.report_type_new == 'purchase':
            sheet.write('A7', "Bill Number ", format2)
            sheet.write('B7', "Billing Date ", format2)
            sheet.write('C7', "Vendor Name", format2)
            sheet.write('D7', "Vendor GST", format2)
            # sheet.write('E7', "Entry Label", format2)
            # sheet.write('F7', "HSN Code", format2)
            # sheet.write('E7', "Qty", format3)
            # sheet.write('E7', "Rate Of Tax", format3)
            sheet.write('E7', "Taxable Value", format3)
            sheet.write('F7', "CGST", format2)
            sheet.write('G7', "SGST", format3)
            sheet.write('H7', "IGST", format3)
            # sheet.write('I7', "CESS", format3)
            # sheet.write('N7', "Place of Supply", format3)
            sheet.write('I7', "Total", format3)

            row = 7
            col = 0
            domain = [('type', '=', 'in_invoice'), ('state', '!=', 'cancel')]
            if active_ref.company_id:
                domain.append(('company_id', '=', active_ref.company_id.id))
            if active_ref.date_from:
                domain.append(('date', '=>', active_ref.date_from))
            if active_ref.date_to:
                domain.append(('date', '<=', active_ref.date_to))
            account = self.env['account.move'].search(domain)
            for record in account:
                # for line in record.invoice_line_ids:
                col = 0
                # row += 1
                sheet.write(row, col, record.name or '', format6)
                sheet.write(row, col + 1, record.date, format8)
                sheet.write(row, col + 2, record.partner_id and record.partner_id.name or '', format6)
                sheet.write(row, col + 3, record.partner_id and record.partner_id.vat or '', format6)
                # sheet.write(row, col +4 , line.name or line.product_id and line.product_id.name or '', format6)
                # sheet.write(row, col +5 , line.product_id and line.product_id.l10n_in_hsn_code or '', format6)
                # sheet.write(row, col +6, line.quantity, format6)
                # sheet.write(row, col +7 , line.tax_ids and line.tax_ids[0].name, format6)
                sheet.write(row, col + 4, record.amount_untaxed, format6)
                cgst = 0
                sgst = 0
                igst = 0
                cess = 0
                for tax in record.amount_by_group:
                    if 'cgst' == tax[0].lower():
                        cgst = tax[1]
                    if 'sgst' == tax[0].lower():
                        sgst = tax[1]
                    if 'igst' == tax[0].lower():
                        igst = tax[1]
                    if 'cess' == tax[0].lower():
                        cess = tax[1]
                sheet.write(row, col + 5, sgst, format6)
                sheet.write(row, col + 6, cgst, format6)
                sheet.write(row, col + 7, igst, format6)
                # sheet.write(row, col +8, cess, format6)
                sheet.write(row, col + 8, record.amount_total, format6)

                # if line.tax_ids:
                #     for tax in line.tax_ids[0].children_tax_ids:
                #         pass

                # sheet.write(row, col +5, tax, format6)
                # sheet.write(row, col +10, sgst, format6)
                # sheet.write(row, col +11, igst, format6)
                # sheet.write(row, col +12, cess, format6)
                # # sheet.write(row, col +13 , 'place of supply', format6)
                # sheet.write(row, col +13, line.price_subtotal, format6)
                row += 1
            # sheet.write('A7', "Bill Number ", format2)
            # sheet.write('B7', "Billing Date ", format2)
            # sheet.write('C7', "Vendor Name", format2)
            # sheet.write('D7', "Vendor GST", format2)
            # sheet.write('E7', "Entry Label", format2)
            # sheet.write('F7', "HSN Code", format2)
            # sheet.write('G7', "Qty", format3)
            # sheet.write('H7', "Rate Of Tax", format3)
            # sheet.write('I7', "Taxable Value", format3)
            # sheet.write('J7', "CGST", format2)
            # sheet.write('K7', "SGST", format3)
            # sheet.write('L7', "IGST", format3)
            # sheet.write('M7', "CESS", format3)
            # # sheet.write('N7', "Place of Supply", format3)
            # sheet.write('N7', "Total", format3)
            #
            # row = 7
            # col = 0
            # domain=[('type','=','in_invoice'),('state','!=','cancel')]
            # if active_ref.company_id:
            #     domain.append(('company_id', '=', active_ref.company_id.id))
            # account=self.env['account.move'].search(domain)
            # for record in account:
            #         for line in record.invoice_line_ids:
            #             col = 0
            #             #row += 1
            #             sheet.write(row, col,record.name or '', format6)
            #             sheet.write(row, col+1, record.date, format8)
            #             sheet.write(row, col + 2, record.partner_id and record.partner_id.name  or '', format6)
            #             sheet.write(row, col +3 ,record.partner_id and record.partner_id.vat  or '', format6)
            #             sheet.write(row, col +4 , line.name or line.product_id and line.product_id.name or '', format6)
            #             sheet.write(row, col +5 , line.product_id and line.product_id.l10n_in_hsn_code or '', format6)
            #             sheet.write(row, col +6, line.quantity, format6)
            #             sheet.write(row, col +7 , line.tax_ids and line.tax_ids[0].name, format6)
            #             sheet.write(row, col +8, line.price_subtotal, format6)
            #             cgst=0
            #             sgst=0
            #             igst=0
            #             cess=0
            #             tax_per=line.tax_ids and line.tax_ids[0].amount or 1
            #             tax=(tax_per * line.price_subtotal)/100
            #             # if line.tax_ids:
            #             #     for tax in line.tax_ids[0].children_tax_ids:
            #             #         pass
            #
            #             sheet.write(row, col +9, tax, format6)
            #             sheet.write(row, col +10, sgst, format6)
            #             sheet.write(row, col +11, igst, format6)
            #             sheet.write(row, col +12, cess, format6)
            #             # sheet.write(row, col +13 , 'place of supply', format6)
            #             sheet.write(row, col +13, line.price_subtotal, format6)
            #             row += 1
        elif active_ref and active_ref.report_type_new == 'sale':
            sheet.write('A7', "Bill Number ", format2)
            sheet.write('B7', "Billing Date ", format2)
            sheet.write('C7', "Vendor Name", format2)
            sheet.write('D7', "Vendor GST", format2)
            # sheet.write('E7', "Entry Label", format2)
            # sheet.write('F7', "HSN Code", format2)
            # sheet.write('E7', "Qty", format3)
            # sheet.write('E7', "Rate Of Tax", format3)
            sheet.write('E7', "Taxable Value", format3)
            sheet.write('F7', "CGST", format2)
            sheet.write('G7', "SGST", format3)
            sheet.write('H7', "IGST", format3)
            # sheet.write('I7', "CESS", format3)
            # sheet.write('N7', "Place of Supply", format3)
            sheet.write('I7', "Total", format3)
            row = 7
            col = 0
            domain = [('type', '=', 'out_invoice'), ('state', '!=', 'cancel')]
            if active_ref.company_id:
                domain.append(('company_id', '=', active_ref.company_id.id))
            if active_ref.date_from:
                domain.append(('date', '=>', active_ref.date_from))
            if active_ref.date_to:
                domain.append(('date', '<=', active_ref.date_to))
            account = self.env['account.move'].search(domain)
            for record in account:
                # for line in record.invoice_line_ids:
                col = 0
                # row += 1
                sheet.write(row, col, record.name or '', format6)
                sheet.write(row, col + 1, record.date, format8)
                sheet.write(row, col + 2, record.partner_id and record.partner_id.name or '', format6)
                sheet.write(row, col + 3, record.partner_id and record.partner_id.vat or '', format6)
                # sheet.write(row, col +4 , line.name or line.product_id and line.product_id.name or '', format6)
                # sheet.write(row, col +5 , line.product_id and line.product_id.l10n_in_hsn_code or '', format6)
                # sheet.write(row, col +6, line.quantity, format6)
                # sheet.write(row, col +7 , line.tax_ids and line.tax_ids[0].name, format6)
                sheet.write(row, col + 4, record.amount_untaxed, format6)
                cgst = 0
                sgst = 0
                igst = 0
                cess = 0
                for tax in record.amount_by_group:
                    if 'cgst' == tax[0].lower():
                        cgst = tax[1]
                    if 'sgst' == tax[0].lower():
                        sgst = tax[1]
                    if 'igst' == tax[0].lower():
                        igst = tax[1]
                    if 'cess' == tax[0].lower():
                        cess = tax[1]
                sheet.write(row, col + 5, sgst, format6)
                sheet.write(row, col + 6, cgst, format6)
                sheet.write(row, col + 7, igst, format6)
                # sheet.write(row, col +8, cess, format6)
                sheet.write(row, col + 8, record.amount_total, format6)

                # if line.tax_ids:
                #     for tax in line.tax_ids[0].children_tax_ids:
                #         pass

                # sheet.write(row, col +5, tax, format6)
                # sheet.write(row, col +10, sgst, format6)
                # sheet.write(row, col +11, igst, format6)
                # sheet.write(row, col +12, cess, format6)
                # # sheet.write(row, col +13 , 'place of supply', format6)
                # sheet.write(row, col +13, line.price_subtotal, format6)
                row += 1
            # sheet.write('A7', "Bill Number ", format2)
            # sheet.write('B7', "Billing Date ", format2)
            # sheet.write('C7', "Vendor Name", format2)
            # sheet.write('D7', "Vendor GST", format2)
            # sheet.write('E7', "Entry Label", format2)
            # sheet.write('F7', "HSN Code", format2)
            # sheet.write('G7', "Qty", format3)
            # sheet.write('H7', "Rate Of Tax", format3)
            # sheet.write('I7', "Taxable Value", format3)
            # sheet.write('J7', "CGST", format2)
            # sheet.write('K7', "SGST", format3)
            # sheet.write('L7', "IGST", format3)
            # sheet.write('M7', "CESS", format3)
            # # sheet.write('N7', "Place of Supply", format3)
            # sheet.write('N7', "Total", format3)
            #
            # row = 7
            # col = 0
            # domain=[('type','=','in_invoice'),('state','!=','cancel')]
            # if active_ref.company_id:
            #     domain.append(('company_id', '=', active_ref.company_id.id))
            # account=self.env['account.move'].search(domain)
            # for record in account:
            #         for line in record.invoice_line_ids:
            #             col = 0
            #             #row += 1
            #             sheet.write(row, col,record.name or '', format6)
            #             sheet.write(row, col+1, record.date, format8)
            #             sheet.write(row, col + 2, record.partner_id and record.partner_id.name  or '', format6)
            #             sheet.write(row, col +3 ,record.partner_id and record.partner_id.vat  or '', format6)
            #             sheet.write(row, col +4 , line.name or line.product_id and line.product_id.name or '', format6)
            #             sheet.write(row, col +5 , line.product_id and line.product_id.l10n_in_hsn_code or '', format6)
            #             sheet.write(row, col +6, line.quantity, format6)
            #             sheet.write(row, col +7 , line.tax_ids and line.tax_ids[0].name, format6)
            #             sheet.write(row, col +8, line.price_subtotal, format6)
            #             cgst=0
            #             sgst=0
            #             igst=0
            #             cess=0
            #             tax_per=line.tax_ids and line.tax_ids[0].amount or 1
            #             tax=(tax_per * line.price_subtotal)/100
            #             # if line.tax_ids:
            #             #     for tax in line.tax_ids[0].children_tax_ids:
            #             #         pass
            #
            #             sheet.write(row, col +9, tax, format6)
            #             sheet.write(row, col +10, sgst, format6)
            #             sheet.write(row, col +11, igst, format6)
            #             sheet.write(row, col +12, cess, format6)
            #             # sheet.write(row, col +13 , 'place of supply', format6)
            #             sheet.write(row, col +13, line.price_subtotal, format6)
            #             row += 1

        else:
            sheet.write('A7', "Date ", format2)
            sheet.write('B7', "JRNL", format2)
            sheet.write('C7', "Partner", format2)
            sheet.write('D7', "Ref", format2)
            sheet.write('E7', "Move", format2)
            sheet.write('F7', "Entry Label", format2)
            sheet.write('G7', "Debit", format3)
            sheet.write('H7', "Credit", format3)
            sheet.write('I7', "Balance", format3)

            row = 7
            col = 0
            for account in results['Accounts']:
                sheet.merge_range(row, col, row, col + 5, account['code'] + account['name'], format4)
                sheet.write(row, col + 6, account['debit'], format5)
                sheet.write(row, col + 7, account['credit'], format5)
                sheet.write(row, col + 8, account['balance'], format5)
                for line in account['move_lines']:
                    col = 0
                    row += 1
                    sheet.write(row, col, line['ldate'], format8)
                    sheet.write(row, col + 1, line['lcode'], format6)
                    sheet.write(row, col + 2, line['partner_name'], format6)
                    sheet.write(row, col + 3, line['lref'] or '', format6)
                    sheet.write(row, col + 4, line['move_name'], format6)
                    sheet.write(row, col + 5, line['lname'], format6)
                    sheet.write(row, col + 6, line['debit'], format7)
                    sheet.write(row, col + 7, line['credit'], format7)
                    sheet.write(row, col + 8, line['balance'], format7)
                row += 1
